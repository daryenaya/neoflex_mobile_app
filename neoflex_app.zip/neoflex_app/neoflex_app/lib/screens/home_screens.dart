import 'package:flutter/material.dart';
import 'package:neoflex_application/models/note_model.dart';
import 'package:neoflex_application/screens/create_note.dart';
import 'package:neoflex_application/screens/feedback_screen.dart';
import 'package:neoflex_application/screens/widgets/note_card.dart';

class HomeScreens extends StatefulWidget {
  const HomeScreens({super.key});

  @override
  State<HomeScreens> createState() => _HomeScreensState();
}

class _HomeScreensState extends State<HomeScreens> {
  List<Note> notes = List.empty(growable: true);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Notes"),
      ),
      body: ListView.builder(
        itemCount: notes.length,
        itemBuilder: (context, index) {
          return NoteCard(note: notes[index], index: index, onNewNoteDeleted: onNewNoteDeleted);
        },
      ),
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(left: 30.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            // Кнопка "Предложения" в левом нижнем углу
            FloatingActionButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const FeedbackScreen(),
                ));
              },
              heroTag: "feedbackButton",
              child: const Icon(Icons.feedback), 
            ),
            FloatingActionButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => CreateNote(
                    onNewNoteCreated: onNewNoteCreated,
                  ),
                ));
              },
              heroTag: "addButton",
              child: const Icon(Icons.add), 
            ),
          ],
        ),
      ),
    );
  }

  void onNewNoteCreated(Note note) {
    notes.add(note);
    setState(() {});
  }

  void onNewNoteDeleted(int index) {
    notes.removeAt(index);
    setState(() {});
  }
}