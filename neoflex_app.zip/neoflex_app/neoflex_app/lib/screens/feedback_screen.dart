import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class FeedbackScreen extends StatefulWidget {
  const FeedbackScreen({super.key});

  @override
  _FeedbackScreenState createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  final TextEditingController _feedbackController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  final RegExp _emailRegExp = RegExp(
    r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
  );

  @override
  void initState() {
    super.initState();
    _loadFeedbackFromJsonAndSaveToDatabase();
  }

  Future<void> _loadFeedbackFromJsonAndSaveToDatabase() async {
    try {
      final feedbackData = await readFeedbackFromJson();
      await saveFeedbackToDatabase(feedbackData);
    } catch (e) {
      print('Error loading and saving feedback data: $e');
    }
  }

  Future<List<Map<String, dynamic>>> readFeedbackFromJson() async {
    final file = File('feedback.json');
    final contents = await file.readAsString();
    final data = jsonDecode(contents) as List<dynamic>;
    return data.cast<Map<String, dynamic>>().toList();
  }

  Future<void> saveFeedbackToDatabase(List<Map<String, dynamic>> feedbackData) async {
    final database = await openDatabase(
  join(await getDatabasesPath(), 'feedback_database.db'),
  onCreate: (db, version) {
    return db.execute(
      'CREATE TABLE feedback(id INTEGER PRIMARY KEY, email TEXT, feedback TEXT)',
    );
  },
  version: 1,
);


    for (final feedback in feedbackData) {
      await database.insert(
        'feedback',
        feedback,
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    }

    print('Feedback data saved to SQLite database.');
  }

  Future<void> _saveFeedbackToDatabase() async {
    final feedback = _feedbackController.text;
    final email = _emailController.text;

    await saveFeedbackToDatabase([
      {'email': email, 'feedback': feedback},
    ]);

    _feedbackController.clear();
    _emailController.clear();

    ScaffoldMessenger.of(context as BuildContext).showSnackBar(
      const SnackBar(
        content: Text('Your feedback has been successfully submitted!'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Feedback"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'E-mail',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please provide your e-mail!';
                  }
                  if (!_emailRegExp.hasMatch(value)) {
                    return 'Please enter a valid e-mail!';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _feedbackController,
                decoration: const InputDecoration(

                  labelText: 'Describe the problem/suggestion',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.all(Radius.circular(16)),
                  ),
                ),
                maxLines: 8,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please fill in the field!';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    _saveFeedbackToDatabase();
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
