import 'package:flutter/material.dart';
import 'package:neoflex_application/screens/db_helper.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    final dbHelper = DatabaseHelper();

    // Проверка введённого логина и пароля
    if (dbHelper.authenticate(_usernameController.text, _passwordController.text)) {
      // Пользователь успешно аутентифицирован
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Login successful!"),
        duration: Duration(seconds: 2),
      ));

      // Здесь можно добавить код для перехода на другой экран или выполнения других операций
      // Например, добавить новый отзыв
      dbHelper.insertFeedback("example@example.com", "This is a test suggestion.");
      
      // Получите данные и отобразите их, если необходимо
    } else {
      // Неверные учетные данные
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("Login failed! Invalid credentials."),
        duration: Duration(seconds: 2),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Login"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(labelText: "Username"),
            ),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: "Password"),
              obscureText: true,
            ),
            ElevatedButton(
              onPressed: _login,
              child: const Text("Login"),
            ),
          ],
        ),
      ),
    );
  }
}
